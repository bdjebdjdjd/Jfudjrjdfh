import { AndroidProjectFile, TargetAppConfig } from './types';

export const TARGET_APPS: TargetAppConfig[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp Messenger',
    packageName: 'com.whatsapp',
    icon: 'MessageCircle',
    themeColor: '#25D366',
    cameraCallType: 'Camera2',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    packageName: 'org.telegram.messenger',
    icon: 'Send',
    themeColor: '#229ED9',
    cameraCallType: 'CameraX',
  },
  {
    id: 'instagram',
    name: 'Instagram Direct Call',
    packageName: 'com.instagram.android',
    icon: 'Camera',
    themeColor: '#E1306C',
    cameraCallType: 'Camera2',
  },
  {
    id: 'meet',
    name: 'Google Meet',
    packageName: 'com.google.android.apps.meetings',
    icon: 'Video',
    themeColor: '#00897B',
    cameraCallType: 'WebRTC',
  },
  {
    id: 'custom',
    name: 'Custom Target App',
    packageName: 'com.custom.targetapp',
    icon: 'Layers',
    themeColor: '#6366F1',
    cameraCallType: 'Camera2',
  },
];

export const getAndroidProjectFiles = (targetPackage: string = 'com.whatsapp'): AndroidProjectFile[] => {
  return [
    {
      path: '.github/workflows/build-apk.yml',
      description: 'GitHub Actions Workflow to automatically build and release .apk artifact on push/dispatch',
      content: `name: Build Android APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Repository
      uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'zulu'
        cache: gradle

    - name: Make gradlew executable
      run: chmod +x ./gradlew

    - name: Build Debug APK with Gradle
      run: ./gradlew assembleDebug --no-daemon --stacktrace

    - name: Upload Debug APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: VirtualCam-app-debug
        path: app/build/outputs/apk/debug/app-debug.apk
        retention-days: 7
`
    },
    {
      path: 'gradlew',
      description: 'Executable Gradle Wrapper script for GitHub Actions & Linux (placed at root)',
      content: `#!/usr/bin/env sh

##############################################################################
##
##  Gradle start up script for UN*X / Linux / GitHub Actions
##
##############################################################################

PRG="$0"
while [ -h "$PRG" ] ; do
    ls=\`ls -ld "$PRG"\`
    link=\`expr "$ls" : '.*-> \\(.*\\)$'\`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=\`dirname "$PRG"\`"/$link"
    fi
done
SAVED="\`pwd\`"
cd "\`dirname \\"$PRG\\"\`/" >/dev/null
APP_HOME="\`pwd -P\`"
cd "$SAVED" >/dev/null

APP_NAME="Gradle"
APP_BASE_NAME=\`basename "$0"\`

DEFAULT_JVM_OPTS='"-Xmx1024m" "-Dfile.encoding=UTF-8"'
MAX_FD="maximum"

warn () {
    echo "$*"
}

die () {
    echo
    echo "$*"
    echo
    exit 1
}

cygwin=false
msys=false
darwin=false
nonstop=false
case "\`uname\`" in
  CYGWIN* ) cygwin=true ;;
  Darwin* ) darwin=true ;;
  MINGW* ) msys=true ;;
  NONSTOP* ) nonstop=true ;;
esac

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar

if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        JAVACMD="$JAVA_HOME/jre/sh/java"
    else
        JAVACMD="$JAVA_HOME/bin/java"
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME"
    fi
else
    JAVACMD="java"
    which java >/dev/null 2>&1 || die "ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH."
fi

for arg do
    case "$arg" in
        "") args="$args \\"\\"";;
        *) args="$args \\"$arg\\"";;
    esac
done

exec "$JAVACMD" $DEFAULT_JVM_OPTS -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain $args
`
    },
    {
      path: 'gradlew.bat',
      description: 'Windows batch script for Gradle Wrapper',
      content: `@rem
@rem Copyright 2015 the original author or authors.
@rem
@if "%DEBUG%" == "" @echo off
@rem ##########################################################################
@rem  Gradle startup script for Windows
@rem ##########################################################################

if "%OS%"=="Windows_NT" setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%

for %%i in ("%APP_HOME%") do set APP_HOME=%%~fi

set DEFAULT_JVM_OPTS="-Xmx1024m" "-Dfile.encoding=UTF-8"

if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if "%ERRORLEVEL%" == "0" goto execute

echo.
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.
goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe

if exist "%JAVA_EXE%" goto execute

echo.
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
goto fail

:execute
set CLASSPATH=%APP_HOME%\\gradle\\wrapper\\gradle-wrapper.jar
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

:fail
exit /b 1
`
    },
    {
      path: 'gradle/wrapper/gradle-wrapper.properties',
      description: 'Gradle wrapper configuration pointing to Gradle 8.7 distribution',
      content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
    },
    {
      path: 'build.gradle',
      description: 'Root build script configured for Android Gradle Plugin 8.5+',
      content: `plugins {
    id 'com.android.application' version '8.5.2' apply false
}

tasks.register('clean', Delete) {
    delete rootProject.layout.buildDirectory
}
`
    },
    {
      path: 'settings.gradle',
      description: 'Project settings and repository resolution for Google, Maven Central, and plugins',
      content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VirtualCamStudio"
include ':app'
`
    },
    {
      path: 'gradle.properties',
      description: 'Gradle daemon and AndroidX properties optimized for CI and JDK 17',
      content: `org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
android.nonTransitiveRClass=true
org.gradle.parallel=true
org.gradle.caching=true
`
    },
    {
      path: 'app/build.gradle',
      description: 'App-level Gradle configuration compatible with Android 16+ (SDK 35) & JDK 17',
      content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.vanta.virtualcam'
    compileSdk 35

    defaultConfig {
        applicationId "com.vanta.virtualcam"
        minSdk 26
        targetSdk 35
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            debuggable true
        }
    }
    
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.core:core:1.13.1'
}
`
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      description: 'Manifest with pure XML vector drawables and all required runtime permissions',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.vanta.virtualcam">

    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" tools:node="merge" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" tools:node="merge" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="VirtualCam Injector"
        android:roundIcon="@drawable/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".service.VirtualCamOverlayService"
            android:exported="false"
            android:foregroundServiceType="camera|microphone" />
    </application>

</manifest>
`
    },
    {
      path: 'app/src/main/res/values/styles.xml',
      description: 'App theme and color definitions (self-contained XML)',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.VirtualCam" parent="Theme.AppCompat.NoActionBar">
        <item name="colorPrimary">#00E676</item>
        <item name="colorPrimaryDark">#00B248</item>
        <item name="colorAccent">#2979FF</item>
        <item name="android:windowBackground">#121212</item>
    </style>
</resources>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_launcher.xml',
      description: 'Self-contained Vector XML icon (Zero external bitmap/PNG dependencies)',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#121212"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#00E676"
        android:pathData="M34,38h40c2.2,0 4,1.8 4,4v24c0,2.2 -1.8,4 -4,4H34c-2.2,0 -4,-1.8 -4,-4V42c0,-2.2 1.8,-4 4,-4z" />
    <path
        android:fillColor="#121212"
        android:pathData="M54,54m-8,0a8,8 0 1,0 16,0a8,8 0 1,0 -16,0" />
    <path
        android:fillColor="#00E676"
        android:pathData="M78,48l10,-6v24l-10,-6z" />
</vector>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_close.xml',
      description: 'Self-contained Vector XML Close icon for overlay window',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z" />
</vector>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_cam_notification.xml',
      description: 'Self-contained Vector XML Camera icon for Foreground Service notification',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00E676"
        android:pathData="M12,12m-3.2,0a3.2,3.2 0 1,0 6.4,0a3.2,3.2 0 1,0 -6.4,0" />
    <path
        android:fillColor="#00E676"
        android:pathData="M9,2L7.17,4H4c-1.1,0 -2,0.9 -2,2v12c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V6c0,-1.1 -0.9,-2 -2,-2h-3.17L15,2H9zm3,15c-2.76,0 -5,-2.24 -5,-5s2.24,-5 5,-5 5,2.24 5,5 -2.24,5 -5,5z" />
</vector>
`
    },
    {
      path: 'app/src/main/java/com/vanta/virtualcam/MainActivity.java',
      description: 'Main Activity with proactive runtime permissions prompt for Overlay, Camera, Mic & Storage',
      content: `package com.vanta.virtualcam;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.vanta.virtualcam.audio.VoiceChangerEngine;
import com.vanta.virtualcam.service.VirtualCamOverlayService;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_OVERLAY_PERMISSION = 1001;
    private static final int REQ_RUNTIME_PERMISSIONS = 1002;
    private static final int REQ_PICK_VIDEO = 1003;

    private Button btnSelectVideo;
    private Button btnStartService;
    private Button btnStopService;
    private Spinner spinnerTargetApp;
    private SeekBar seekPitch;
    private TextView txtPitchValue;
    private Uri selectedVideoUri;
    private VoiceChangerEngine voiceChangerEngine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSelectVideo = findViewById(R.id.btnSelectVideo);
        btnStartService = findViewById(R.id.btnStartService);
        btnStopService = findViewById(R.id.btnStopService);
        spinnerTargetApp = findViewById(R.id.spinnerTargetApp);
        seekPitch = findViewById(R.id.seekPitch);
        txtPitchValue = findViewById(R.id.txtPitchValue);

        voiceChangerEngine = new VoiceChangerEngine();

        // 1. Immediately request all runtime permissions on launch
        requestAllPermissions();

        btnSelectVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pickIntent = new Intent(Intent.ACTION_GET_CONTENT);
                pickIntent.setType("video/*");
                startActivityForResult(pickIntent, REQ_PICK_VIDEO);
            }
        });

        seekPitch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float pitch = 0.5f + (progress / 100.0f) * 1.5f; // Range: 0.5x to 2.0x
                txtPitchValue.setText(String.format("Pitch: %.2fx", pitch));
                voiceChangerEngine.setPitch(pitch);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnStartService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndEnforcePermissions()) {
                    startVirtualCamService();
                }
            }
        });

        btnStopService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopVirtualCamService();
            }
        });
    }

    private void requestAllPermissions() {
        List<String> permissions = new ArrayList<>();
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_MEDIA_VIDEO);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), REQ_RUNTIME_PERMISSIONS);
        } else {
            checkOverlayPermission();
        }
    }

    private boolean checkAndEnforcePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            promptOverlayPermissionDialog();
            return false;
        }
        return true;
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            promptOverlayPermissionDialog();
        }
    }

    private void promptOverlayPermissionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Overlay Permission Required")
                .setMessage("To display the video feed on top of WhatsApp and other apps, please enable 'Display over other apps' in Android settings.")
                .setPositiveButton("Grant Permission", (dialog, which) -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQ_OVERLAY_PERMISSION);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RUNTIME_PERMISSIONS) {
            checkOverlayPermission();
        }
    }

    private void startVirtualCamService() {
        Intent serviceIntent = new Intent(this, VirtualCamOverlayService.class);
        if (selectedVideoUri != null) {
            serviceIntent.putExtra("VIDEO_URI", selectedVideoUri.toString());
        }
        serviceIntent.putExtra("TARGET_PACKAGE", "${targetPackage}");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        voiceChangerEngine.start();
        Toast.makeText(this, "Virtual Cam & Voice Modulator Active!", Toast.LENGTH_SHORT).show();
    }

    private void stopVirtualCamService() {
        Intent serviceIntent = new Intent(this, VirtualCamOverlayService.class);
        stopService(serviceIntent);
        voiceChangerEngine.stop();
        Toast.makeText(this, "Injection Terminated. Camera reset to normal.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == Activity.RESULT_OK && data != null) {
            selectedVideoUri = data.getData();
            Toast.makeText(this, "Target video loaded: " + selectedVideoUri.getLastPathSegment(), Toast.LENGTH_LONG).show();
        } else if (requestCode == REQ_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay Permission Granted!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (voiceChangerEngine != null) {
            voiceChangerEngine.stop();
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/vanta/virtualcam/service/VirtualCamOverlayService.java',
      description: 'Foreground Floating Window Service with vector notification icon & self-contained drawables',
      content: `package com.vanta.virtualcam.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.VideoView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import com.vanta.virtualcam.MainActivity;
import com.vanta.virtualcam.R;

public class VirtualCamOverlayService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private VideoView videoPlayer;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(101, createNotification());

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        floatingView = inflater.inflate(R.layout.layout_floating_camera, null);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                420,
                580,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80;
        params.y = 150;

        windowManager.addView(floatingView, params);

        videoPlayer = floatingView.findViewById(R.id.floatingVideoView);
        ImageView btnClose = floatingView.findViewById(R.id.btnCloseOverlay);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });

        // Drag & Move support on top of video call screen
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("VIDEO_URI")) {
            String uriStr = intent.getStringExtra("VIDEO_URI");
            videoPlayer.setVideoURI(Uri.parse(uriStr));
            videoPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.setLooping(true);
                    videoPlayer.start();
                }
            });
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "VirtualCamChannel",
                    "Virtual Cam Stream Injection",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, "VirtualCamChannel")
                .setContentTitle("Virtual Cam Injection Active")
                .setContentText("Broadcasting customized face loop to active call")
                .setSmallIcon(R.drawable.ic_cam_notification)
                .setContentIntent(pendingIntent)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
`
    },
    {
      path: 'app/src/main/java/com/vanta/virtualcam/audio/VoiceChangerEngine.java',
      description: 'Real-time pitch modulator reading Mic input and writing modified sample buffer to AudioTrack',
      content: `package com.vanta.virtualcam.audio;

import android.annotation.SuppressLint;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

public class VoiceChangerEngine {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    private boolean isRunning = false;
    private float pitchFactor = 1.0f;
    private Thread workerThread;

    public void setPitch(float pitch) {
        this.pitchFactor = Math.max(0.4f, Math.min(2.5f, pitch));
    }

    @SuppressLint("MissingPermission")
    public synchronized void start() {
        if (isRunning) return;
        isRunning = true;

        int bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING);
        if (bufferSize <= 0) bufferSize = 2048;

        AudioRecord recorder = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_IN,
                ENCODING,
                bufferSize * 2
        );

        AudioTrack track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(ENCODING)
                        .setSampleRate((int) (SAMPLE_RATE * pitchFactor))
                        .setChannelMask(CHANNEL_OUT)
                        .build())
                .setBufferSizeInBytes(bufferSize * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();

        recorder.startRecording();
        track.play();

        workerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                short[] buffer = new short[bufferSize];
                while (isRunning) {
                    int read = recorder.read(buffer, 0, buffer.length);
                    if (read > 0) {
                        track.write(buffer, 0, read);
                    }
                }
                try {
                    recorder.stop();
                    recorder.release();
                    track.stop();
                    track.release();
                } catch (Exception ignored) {}
            }
        });

        workerThread.setPriority(Thread.MAX_PRIORITY);
        workerThread.start();
    }

    public synchronized void stop() {
        isRunning = false;
        if (workerThread != null) {
            try {
                workerThread.join(400);
            } catch (InterruptedException ignored) {}
            workerThread = null;
        }
    }
}
`
    },
    {
      path: 'app/src/main/res/layout/activity_main.xml',
      description: 'Clean Layout XML using only built-in Hex colors and pure Android elements',
      content: `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#121212"
    android:padding="16dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="VIRTUAL CAM &amp; AUDIO INJECTOR"
        android:textColor="#00E676"
        android:textSize="18sp"
        android:textStyle="bold" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Non-Rooted Android 16+ Injection Engine"
        android:textColor="#888888"
        android:textSize="12sp"
        android:layout_marginBottom="16dp" />

    <!-- App Selector -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Target Video Call Application:"
        android:textColor="#FFFFFF"
        android:textSize="14sp" />

    <Spinner
        android:id="@+id/spinnerTargetApp"
        android:layout_width="match_parent"
        android:layout_height="48dp"
        android:background="#1E1E1E"
        android:layout_marginBottom="16dp" />

    <!-- Video Selection -->
    <Button
        android:id="@+id/btnSelectVideo"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:backgroundTint="#2979FF"
        android:text="LOAD INJECTION VIDEO (e.g. Elon Musk Face)"
        android:textColor="#FFFFFF" />

    <!-- Voice Pitch Controls -->
    <TextView
        android:id="@+id/txtPitchValue"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Real-Time Voice Pitch: 1.00x"
        android:textColor="#FFFFFF"
        android:layout_marginTop="20dp" />

    <SeekBar
        android:id="@+id/seekPitch"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:max="100"
        android:progress="33" />

    <!-- Action Buttons -->
    <Button
        android:id="@+id/btnStartService"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:backgroundTint="#00C853"
        android:text="START INJECTION OVERLAY"
        android:textColor="#FFFFFF" />

    <Button
        android:id="@+id/btnStopService"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp"
        android:backgroundTint="#D50000"
        android:text="STOP &amp; RESTORE NORMAL CAMERA"
        android:textColor="#FFFFFF" />

</LinearLayout>
`
    },
    {
      path: 'app/src/main/res/layout/layout_floating_camera.xml',
      description: 'Floating window layout referencing pure vector @drawable/ic_close',
      content: `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#000000">

    <VideoView
        android:id="@+id/floatingVideoView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

    <ImageView
        android:id="@+id/btnCloseOverlay"
        android:layout_width="36dp"
        android:layout_height="36dp"
        android:layout_gravity="top|end"
        android:layout_margin="8dp"
        android:padding="6dp"
        android:src="@drawable/ic_close"
        android:background="#88000000" />
</FrameLayout>
`
    }
  ];
};
