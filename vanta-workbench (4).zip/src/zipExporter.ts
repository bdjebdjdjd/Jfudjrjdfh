import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { getAndroidProjectFiles } from './projectFiles';

export const exportAndroidProjectZip = async (targetAppPackage: string = 'com.whatsapp') => {
  const zip = new JSZip();
  const files = getAndroidProjectFiles(targetAppPackage);

  files.forEach((file) => {
    // Check if it's the executable gradlew unix script and mark executable bit if possible
    if (file.path === 'gradlew') {
      zip.file(file.path, file.content, {
        unixPermissions: '755',
      });
    } else {
      zip.file(file.path, file.content);
    }
  });

  const blob = await zip.generateAsync({
    type: 'blob',
    platform: 'UNIX',
  });
  saveAs(blob, 'VirtualCam_Android_Project.zip');
};
