import React, { useState } from 'react';
import { AndroidProjectFile } from '../types';
import { getAndroidProjectFiles } from '../projectFiles';
import { exportAndroidProjectZip } from '../zipExporter';
import { Download, FileCode, Copy, Check, Terminal, Smartphone, FolderTree } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ProjectCodeViewerProps {
  targetPackage: string;
}

export const ProjectCodeViewer: React.FC<ProjectCodeViewerProps> = ({ targetPackage }) => {
  const files: AndroidProjectFile[] = getAndroidProjectFiles(targetPackage);
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(files[2]); // MainActivity.java by default
  const [copied, setCopied] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      await exportAndroidProjectZip(targetPackage);
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.8 },
      });
    } catch (e) {
      console.error('Export failed:', e);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl overflow-hidden font-mono text-xs flex flex-col h-full">
      {/* Header with Download Action */}
      <div className="p-4 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-emerald-400 font-bold flex items-center gap-2 text-sm">
            <Smartphone className="w-4 h-4" />
            <span>Android IDE Project Structure (Android 16+ / Non-Root)</span>
          </div>
          <div className="text-neutral-500 text-[11px]">
            Target: {targetPackage} | Compatible with AIDE &amp; AndroidIDE on-device builds
          </div>
        </div>

        <button
          type="button"
          onClick={handleDownloadZip}
          disabled={isExporting}
          className="bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-neutral-950 font-bold px-4 py-2 rounded-lg flex items-center gap-2 transition-colors cursor-pointer shadow-lg shadow-emerald-950/40"
        >
          <Download className="w-4 h-4" />
          <span>{isExporting ? 'Packaging...' : 'Export Complete Project (.ZIP)'}</span>
        </button>
      </div>

      {/* Main split: File Tree + Code Editor */}
      <div className="flex-1 flex flex-col md:flex-row min-h-[420px]">
        {/* File Navigator */}
        <div className="w-full md:w-72 bg-neutral-950/70 border-r border-neutral-800 p-3 space-y-1 overflow-y-auto">
          <div className="text-[11px] text-neutral-500 font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <FolderTree className="w-3.5 h-3.5" /> Project Files
          </div>
          {files.map((file) => {
            const fileName = file.path.split('/').pop();
            const isSelected = selectedFile.path === file.path;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-2.5 py-1.5 rounded text-[11px] transition-colors flex items-center gap-2 ${
                  isSelected
                    ? 'bg-neutral-800 text-emerald-400 font-semibold'
                    : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200'
                }`}
              >
                <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-neutral-500'}`} />
                <span className="truncate">{fileName}</span>
              </button>
            );
          })}
        </div>

        {/* Code Content View */}
        <div className="flex-1 bg-neutral-950 flex flex-col overflow-hidden">
          <div className="px-4 py-2 bg-neutral-900/40 border-b border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
            <span className="text-emerald-400/90 font-medium truncate">{selectedFile.path}</span>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy File'}</span>
            </button>
          </div>

          <div className="p-3 bg-neutral-900/20 text-[10px] text-neutral-500 border-b border-neutral-900">
            ℹ️ {selectedFile.description}
          </div>

          <pre className="flex-1 p-4 overflow-auto text-[11px] leading-relaxed text-neutral-300 font-mono bg-neutral-950/90 select-text">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
