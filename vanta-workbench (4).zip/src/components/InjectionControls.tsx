import React, { useState } from 'react';
import { TargetAppConfig, VideoFilterConfig, VideoSourceType } from '../types';
import { TARGET_APPS } from '../projectFiles';
import {
  Sparkles,
  Upload,
  Layers,
  Camera,
  Sliders,
  CheckCircle2,
  Play,
  RotateCcw,
  Zap,
  HelpCircle,
} from 'lucide-react';

interface InjectionControlsProps {
  targetApp: TargetAppConfig;
  onSelectTargetApp: (app: TargetAppConfig) => void;
  videoSourceType: VideoSourceType;
  onSelectVideoSource: (type: VideoSourceType) => void;
  uploadedVideoUrl: string | null;
  onUploadVideo: (e: React.ChangeEvent<HTMLInputElement>) => void;
  videoFilterConfig: VideoFilterConfig;
  onChangeVideoFilter: (config: VideoFilterConfig) => void;
  isInjecting: boolean;
  onStartInjection: () => void;
  onStopInjection: () => void;
}

export const InjectionControls: React.FC<InjectionControlsProps> = ({
  targetApp,
  onSelectTargetApp,
  videoSourceType,
  onSelectVideoSource,
  uploadedVideoUrl,
  onUploadVideo,
  videoFilterConfig,
  onChangeVideoFilter,
  isInjecting,
  onStartInjection,
  onStopInjection,
}) => {
  const [customPackage, setCustomPackage] = useState('com.custom.targetapp');

  return (
    <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 font-mono text-xs space-y-6">
      {/* 1. Target App Selection */}
      <div className="space-y-2">
        <label className="text-neutral-300 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
          <Layers className="w-3.5 h-3.5 text-emerald-400" />
          <span>1. Select Target Calling App</span>
        </label>
        <p className="text-[11px] text-neutral-500">
          Choose which video calling app session you want to inject the virtual camera stream into:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
          {TARGET_APPS.map((app) => {
            const isSelected = targetApp.id === app.id;
            return (
              <button
                key={app.id}
                type="button"
                onClick={() => onSelectTargetApp(app)}
                className={`p-3 rounded-lg border text-left transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-neutral-800 border-emerald-500 text-white shadow-md shadow-emerald-950/40'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold truncate">{app.name}</span>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
                <span className="text-[9px] text-neutral-500 font-mono mt-2 truncate">
                  {app.packageName}
                </span>
              </button>
            );
          })}
        </div>

        {targetApp.id === 'custom' && (
          <div className="mt-2 flex gap-2">
            <input
              type="text"
              value={customPackage}
              onChange={(e) => {
                setCustomPackage(e.target.value);
                onSelectTargetApp({ ...targetApp, packageName: e.target.value });
              }}
              placeholder="e.g. com.tencent.mm (WeChat) or any package"
              className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        )}
      </div>

      {/* 2. Video Injection Source */}
      <div className="space-y-2 border-t border-neutral-800/80 pt-4">
        <label className="text-neutral-300 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
          <Upload className="w-3.5 h-3.5 text-cyan-400" />
          <span>2. Select Face / Video Stream Payload</span>
        </label>
        <p className="text-[11px] text-neutral-500">
          Pick the pre-recorded video or upload your own (e.g. Elon Musk face video) to feed into the webcam:
        </p>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onClick={() => onSelectVideoSource('sample_elon')}
            className={`p-3 rounded-lg border text-left transition-all ${
              videoSourceType === 'sample_elon'
                ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200'
                : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="font-bold text-xs">🚀 Elon Musk Face Loop</div>
            <div className="text-[10px] text-neutral-500 mt-1">Simulated deep synthetic feed with eye &amp; mouth sync</div>
          </button>

          <label
            className={`p-3 rounded-lg border text-left transition-all cursor-pointer block ${
              videoSourceType === 'custom_upload'
                ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200'
                : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <input
              type="file"
              accept="video/*"
              onChange={(e) => {
                onSelectVideoSource('custom_upload');
                onUploadVideo(e);
              }}
              className="hidden"
            />
            <div className="font-bold text-xs flex items-center justify-between">
              <span>📁 Upload Custom Video (MP4)</span>
              {uploadedVideoUrl && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
            </div>
            <div className="text-[10px] text-neutral-500 mt-1 truncate">
              {uploadedVideoUrl ? 'Custom video loaded' : 'Pick any video file from phone storage'}
            </div>
          </label>
        </div>
      </div>

      {/* 3. Real-Time Video Filters & Background Blur */}
      <div className="space-y-3 border-t border-neutral-800/80 pt-4">
        <label className="text-neutral-300 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>3. Real-Time Video Filters &amp; Studio FX</span>
        </label>

        {/* Background Blur Toggle */}
        <div className="flex items-center justify-between p-3 bg-neutral-950/60 border border-neutral-800 rounded-lg">
          <div>
            <div className="font-bold text-xs text-neutral-200">Background Blur (Bokeh FX)</div>
            <div className="text-[10px] text-neutral-500">Real-time background isolation during call</div>
          </div>
          <button
            type="button"
            onClick={() =>
              onChangeVideoFilter({
                ...videoFilterConfig,
                blurBackground: !videoFilterConfig.blurBackground,
              })
            }
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              videoFilterConfig.blurBackground ? 'bg-emerald-500' : 'bg-neutral-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                videoFilterConfig.blurBackground ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Face Tracking HUD Toggle */}
        <div className="flex items-center justify-between p-3 bg-neutral-950/60 border border-neutral-800 rounded-lg">
          <div>
            <div className="font-bold text-xs text-neutral-200">Face Mesh &amp; Target Lock HUD</div>
            <div className="text-[10px] text-neutral-500">Displays real-time facial landmark tracking grid</div>
          </div>
          <button
            type="button"
            onClick={() =>
              onChangeVideoFilter({
                ...videoFilterConfig,
                faceTrackingOverlay: !videoFilterConfig.faceTrackingOverlay,
              })
            }
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              videoFilterConfig.faceTrackingOverlay ? 'bg-cyan-500' : 'bg-neutral-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                videoFilterConfig.faceTrackingOverlay ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Color Grading Filter Options */}
        <div className="space-y-1.5 pt-1">
          <span className="text-[10px] text-neutral-400">Color Grade Presets:</span>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { id: 'none', label: 'Normal' },
              { id: 'cyberpunk', label: 'Cyberpunk' },
              { id: 'matrix', label: 'Matrix' },
              { id: 'nightvision', label: 'Night Vision' },
              { id: 'vintage', label: 'Vintage 90s' },
              { id: 'glitch', label: 'Glitch FX' },
            ].map((fx) => (
              <button
                key={fx.id}
                type="button"
                onClick={() =>
                  onChangeVideoFilter({
                    ...videoFilterConfig,
                    filterEffect: fx.id as VideoFilterConfig['filterEffect'],
                  })
                }
                className={`py-1.5 px-2 rounded text-[10px] font-semibold border transition-all text-center ${
                  videoFilterConfig.filterEffect === fx.id
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {fx.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Main Trigger Buttons (Start / Stop Injection) */}
      <div className="border-t border-neutral-800/80 pt-4 space-y-2">
        {!isInjecting ? (
          <button
            type="button"
            onClick={onStartInjection}
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-neutral-950 font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>START VIRTUAL CAM INJECTION</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onStopInjection}
            className="w-full py-3.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 cursor-pointer animate-pulse"
          >
            <RotateCcw className="w-4 h-4" />
            <span>STOP INJECTION (RESTORE NORMAL CAMERA)</span>
          </button>
        )}
      </div>
    </div>
  );
};
